from setuptools import setup,find_packages


setup(
      author="DataScience Engineer",
      author_email="engineer.datascience@gmail.com",
      packages=find_packages(),
      include_package_data=True,
      name='common_utils',
      version='0.0.1',
      description='common_utils',
)