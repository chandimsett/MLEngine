class DataProcessorContext:
    """
    Context for DataProcessor module
    """
    def __init__(self):
        pass

class ModelGeneratorContext:
    """
    Context for ModelGenerator module
    """
    def __init__(self):
        pass


class ModelPredictorContext:
    """
    Context for ModelPredictor module
    """
    def __init__(self):
        pass