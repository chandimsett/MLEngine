from setuptools import setup,find_packages
setup(
      author="chandim",
      author_email="chandimsett@gmail.com",
      packages=find_packages(),
      include_package_data=True,
      name='ml_automation',
      version='0.0.2',
      description='ml_automation',
)